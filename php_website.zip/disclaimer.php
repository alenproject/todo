<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Disclaimer</title>
</head>
<body>
    <h1>Disclaimer</h1>
    <h2>General Disclaimer</h2>
    <p>The content provided on this website is for informational and entertainment purposes only. We do not guarantee the accuracy or availability of games linked or embedded on our site.</p>

    <h2>External Links</h2>
    <p>We may link to third-party sites. We are not responsible for the content or policies of external sites.</p>

    <h2>Game Copyright</h2>
    <p>All games featured belong to their respective owners. We do not claim ownership and host only where legally permitted or embed from authorized sources.</p>

    <p><a href="index.php">Return to Home</a></p>
</body>
</html>