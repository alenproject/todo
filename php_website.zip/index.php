<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to Our Gaming Site</title>
</head>
<body>
    <h1>Welcome to Our Free Games Portal</h1>
    <p>Explore our collection of PC Games, Browser Games, Free Games, Online Games, Flash Games, Chess Online, Solitaire, Freecell, and Mahjong!</p>
    <nav>
        <ul>
            <li><a href="about.php">About Us</a></li>
            <li><a href="privacy.php">Privacy Policy</a></li>
            <li><a href="terms.php">Terms and Conditions</a></li>
            <li><a href="disclaimer.php">Disclaimer</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </nav>
</body>
</html>